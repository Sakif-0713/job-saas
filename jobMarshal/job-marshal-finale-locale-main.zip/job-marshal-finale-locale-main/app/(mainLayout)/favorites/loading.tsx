import JobListingsLoading from "@/components/general/JobListingsLoading";
import React from "react";

const LoadingJobs = () => {
  return <JobListingsLoading />;
};

export default LoadingJobs;
